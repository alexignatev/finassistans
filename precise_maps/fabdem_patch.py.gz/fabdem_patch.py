from __future__ import annotations

import csv
import hashlib
import json
import math
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import fabdem
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import rasterio
from PIL import Image, ImageDraw
from pyproj import CRS, Transformer
from rasterio.features import geometry_mask
from rasterio.warp import Resampling, reproject
from shapely.geometry import mapping, shape
from shapely.ops import transform as shp_transform

CAD = "22:43:010001:1229"
ROOT = Path("precise_maps_output") / "22_43_010001_1229"
MODEL = ROOT / "01_dem_models" / "05_fabdem"
COMP = ROOT / "02_components"
CMP = ROOT / "03_comparison"
SRC_GEO = ROOT / "00_sources" / "parcel_all_components.geojson"
ZIP_PATH = Path("precise_maps_22_43_010001_1229.zip")
NODATA = -9999.0
MODEL.mkdir(parents=True, exist_ok=True)
CMP.mkdir(parents=True, exist_ok=True)


def write_tif(path: Path, arr: np.ndarray, transform, crs, tags: dict[str, str] | None = None) -> None:
    data = np.where(np.isfinite(arr), arr, NODATA).astype("float32")
    profile = {
        "driver": "GTiff", "height": data.shape[0], "width": data.shape[1], "count": 1,
        "dtype": "float32", "crs": crs, "transform": transform, "nodata": NODATA,
        "compress": "deflate", "predictor": 3, "tiled": True,
    }
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(data, 1)
        if tags: dst.update_tags(**tags)
        factors = [f for f in (2, 4, 8, 16) if min(data.shape) // f >= 16]
        if factors:
            dst.build_overviews(factors, Resampling.average)
            dst.update_tags(ns="rio_overview", resampling="average")


def mask_arr(arr: np.ndarray, transform, geom) -> np.ndarray:
    inside = geometry_mask([mapping(geom)], out_shape=arr.shape, transform=transform, invert=True)
    return np.where(inside, arr, np.nan)


def derivs(dem: np.ndarray, px: float = 30.0) -> dict[str, np.ndarray]:
    filled = np.where(np.isfinite(dem), dem, np.nanmedian(dem))
    gy, gx = np.gradient(filled, px, px)
    rise = np.hypot(gx, gy)
    slope = np.degrees(np.arctan(rise))
    aspect = (np.degrees(np.arctan2(-gx, gy)) + 360) % 360
    az, alt = math.radians(315), math.radians(45)
    hs = np.sin(alt) * np.cos(np.arctan(rise)) + np.cos(alt) * np.sin(np.arctan(rise)) * np.cos(az - np.arctan2(-gx, gy))
    hs = (hs - np.nanmin(hs)) / max(np.nanmax(hs) - np.nanmin(hs), 1e-6)
    from scipy.ndimage import uniform_filter, maximum_filter, minimum_filter
    tpi = filled - uniform_filter(filled, size=9, mode="nearest")
    tri = maximum_filter(filled, size=3) - minimum_filter(filled, size=3)
    valid = np.isfinite(dem)
    return {
        "hillshade": np.where(valid, hs, np.nan),
        "slope_deg": np.where(valid, slope, np.nan),
        "slope_pct": np.where(valid, rise * 100, np.nan),
        "aspect": np.where(valid, aspect, np.nan),
        "tri": np.where(valid, tri, np.nan),
        "tpi": np.where(valid, tpi, np.nan),
    }


def plot(path: Path, arr: np.ndarray, transform, geom, title: str, cmap: str = "terrain", label: str = "м") -> None:
    fig, ax = plt.subplots(figsize=(12, 9), dpi=180)
    extent = [transform.c, transform.c + transform.a * arr.shape[1], transform.f + transform.e * arr.shape[0], transform.f]
    finite = arr[np.isfinite(arr)]
    kwargs = {}
    if finite.size and cmap == "RdBu_r":
        lim = max(abs(np.percentile(finite, 2)), abs(np.percentile(finite, 98)), 0.1)
        kwargs = {"vmin": -lim, "vmax": lim}
    im = ax.imshow(arr, extent=extent, origin="upper", cmap=cmap, **kwargs)
    geoms = list(geom.geoms) if geom.geom_type == "MultiPolygon" else [geom]
    for g in geoms:
        x, y = g.exterior.xy
        ax.plot(x, y, color="red", linewidth=1.8)
    ax.set_aspect("equal")
    ax.set_title(title)
    ax.set_xlabel("Easting, UTM 44N")
    ax.set_ylabel("Northing, UTM 44N")
    cb = fig.colorbar(im, ax=ax, shrink=0.82)
    cb.set_label(label)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


geo = json.loads(SRC_GEO.read_text(encoding="utf-8"))
geom_wgs = shape(geo["features"][0]["geometry"])
w, s, e, n = geom_wgs.bounds
margin = 0.02
native = MODEL / "native_unresampled_clip.tif"
fabdem.download((w - margin, s - margin, e + margin, n + margin), output_path=native, cache=Path(".fabdem-cache"), show_progress=False)

reference = ROOT / "01_dem_models" / "01_copernicus_glo30" / "dem_buffered_utm44n_30m.tif"
with rasterio.open(reference) as ref:
    transform, crs, height, width = ref.transform, ref.crs, ref.height, ref.width
    cop = ref.read(1).astype("float32")
    cop[cop == ref.nodata] = np.nan
with rasterio.open(native) as src:
    dem = np.full((height, width), np.nan, dtype="float32")
    reproject(
        source=rasterio.band(src, 1), destination=dem,
        src_transform=src.transform, src_crs=src.crs, src_nodata=src.nodata,
        dst_transform=transform, dst_crs=crs, dst_nodata=np.nan,
        resampling=Resampling.bilinear,
    )

utm = CRS.from_user_input(crs)
to_utm = Transformer.from_crs(4326, utm, always_xy=True).transform
geom_utm = shp_transform(to_utm, geom_wgs)
tags = {
    "dataset": "FABDEM V1.2 bare-earth",
    "vertical_datum": "EGM2008",
    "license": "CC BY-NC-SA 4.0",
    "created_utc": datetime.now(timezone.utc).isoformat(),
}
masked = mask_arr(dem, transform, geom_utm)
write_tif(MODEL / "dem_buffered_utm44n_30m.tif", dem, transform, crs, tags)
write_tif(MODEL / "dem_parcel_masked_utm44n_30m.tif", masked, transform, crs, tags)
plot(MODEL / "00_elevation.png", masked, transform, geom_utm, "FABDEM V1.2: высота без леса и зданий (EGM2008)")
styles = {
    "hillshade": ("gray", "0–1"), "slope_deg": ("magma", "°"), "slope_pct": ("magma", "%"),
    "aspect": ("twilight", "градусы"), "tri": ("viridis", "м"), "tpi": ("RdBu_r", "м"),
}
d = derivs(dem)
for key, arr in d.items():
    write_tif(MODEL / f"{key}.tif", arr, transform, crs, tags)
    cmap, label = styles[key]
    plot(MODEL / f"{key}.png", mask_arr(arr, transform, geom_utm), transform, geom_utm, f"FABDEM V1.2: {key}", cmap, label)

v = masked[np.isfinite(masked)]
sv = mask_arr(d["slope_deg"], transform, geom_utm)
sv = sv[np.isfinite(sv)]
stats = {
    "dataset": "FABDEM V1.2 bare-earth", "vertical_datum": "EGM2008", "resolution": "1 arc-second / common 30 m grid",
    "license": "CC BY-NC-SA 4.0", "cells_inside": int(v.size),
    "min_m": float(v.min()), "max_m": float(v.max()), "mean_m": float(v.mean()),
    "median_m": float(np.median(v)), "std_m": float(v.std()),
    "slope_deg": {"mean": float(sv.mean()), "p50": float(np.percentile(sv, 50)), "p90": float(np.percentile(sv, 90)), "max": float(sv.max())},
}
(MODEL / "stats.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
(MODEL / "source_metadata.json").write_text(json.dumps({
    "source": "University of Bristol FABDEM V1.2 via fabdem Python downloader",
    "bounds_requested_wgs84": [w - margin, s - margin, e + margin, n + margin],
    "vertical_datum": "EGM2008", "license": "CC BY-NC-SA 4.0",
}, ensure_ascii=False, indent=2), encoding="utf-8")

# Direct same-datum comparison with Copernicus GLO-30.
diff = cop - dem
write_tif(CMP / "copernicus_minus_fabdem.tif", diff, transform, crs, {"vertical_datum": "EGM2008"})
plot(CMP / "copernicus_minus_fabdem.png", mask_arr(diff, transform, geom_utm), transform, geom_utm, "Copernicus GLO-30 − FABDEM V1.2", "RdBu_r", "м")

# Per-component exact masks and visual maps.
for folder in sorted(COMP.glob("component_*")):
    component_geo = json.loads((folder / "component.geojson").read_text(encoding="utf-8"))
    g_wgs = shape(component_geo["features"][0]["geometry"])
    g_utm = shp_transform(to_utm, g_wgs)
    component = mask_arr(dem, transform, g_utm)
    write_tif(folder / "05_fabdem_component_30m.tif", component, transform, crs, tags)
    plot(folder / "05_fabdem_elevation.png", component, transform, g_utm, "FABDEM V1.2: высота", "terrain", "м")
    sp = folder / "stats.json"
    current = json.loads(sp.read_text(encoding="utf-8")) if sp.exists() else {}
    cv = component[np.isfinite(component)]
    current.setdefault("models", {})["05_fabdem"] = {
        "cells": int(cv.size), "min_m": float(cv.min()), "max_m": float(cv.max()),
        "mean_m": float(cv.mean()), "median_m": float(np.median(cv)), "std_m": float(cv.std()),
    }
    sp.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")

    images = sorted(folder.glob("*_elevation.png"))
    if images:
        thumbs = []
        for p in images:
            im = Image.open(p).convert("RGB")
            im.thumbnail((720, 520))
            thumbs.append((p.name, im.copy()))
        cols, rows = 2, math.ceil(len(thumbs) / 2)
        sheet = Image.new("RGB", (cols * 760, rows * 570), "white")
        draw = ImageDraw.Draw(sheet)
        for idx, (name, im) in enumerate(thumbs):
            x, y = (idx % cols) * 760, (idx // cols) * 570
            sheet.paste(im, (x + 20, y + 35))
            draw.text((x + 20, y + 10), name, fill="black")
        sheet.save(folder / "00_precision_contact_sheet.jpg", quality=92)

# Clear the prior FABDEM failure while retaining audit history.
errors_path = ROOT / "errors.json"
errors = json.loads(errors_path.read_text(encoding="utf-8")) if errors_path.exists() else []
errors = [x for x in errors if x.get("stage") != "FABDEM"]
errors_path.write_text(json.dumps(errors, ensure_ascii=False, indent=2), encoding="utf-8")

readme_path = ROOT / "00_README.md"
readme = readme_path.read_text(encoding="utf-8")
readme = readme.replace("и, если источник отдал файл, FABDEM V1.2", "и FABDEM V1.2")
readme += "\n## Дополнение FABDEM\n\nFABDEM V1.2 успешно добавлен через официальный набор University of Bristol. Это модель Copernicus GLO-30 с удалёнными модельными высотами леса и зданий. Лицензия CC BY-NC-SA 4.0 ограничивает коммерческое использование.\n"
readme_path.write_text(readme, encoding="utf-8")

# Rebuild manifest and package.
rows = []
for p in sorted(ROOT.rglob("*")):
    if p.is_file():
        rows.append({"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size, "sha256": sha256(p)})
(ROOT / "manifest.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
with (ROOT / "manifest.csv").open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=["path", "bytes", "sha256"])
    writer.writeheader(); writer.writerows(rows)
if ZIP_PATH.exists(): ZIP_PATH.unlink()
with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
    for p in sorted(ROOT.rglob("*")):
        if p.is_file(): z.write(p, Path(ROOT.name) / p.relative_to(ROOT))
print(json.dumps({"fabdem": stats, "package_bytes": ZIP_PATH.stat().st_size, "files": len(rows)}, ensure_ascii=False))
